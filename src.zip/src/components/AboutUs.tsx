import React, { useState } from 'react';


const AboutUs: React.FC<AboutUsProps> = ({ isSidebarHovered }) => {

  return (
    <div className={`relative w-full m-10 max-w-7xl mx-auto flex gap-6 transition-all duration-300 ease-in-out ${isSidebarHovered ? 'blur-sm' : ''}`}>
      <div className="w-full p-8 bg-white/10 backdrop-blur-md rounded-xl border border-[#61C3CB75] text-white">
        <h1 className="text-3xl font-bold mb-4">About Us</h1>
        <p className="text-lg mb-4">
          We are dedicated to providing the best firewall management solutions with the help of AI. Our team is passionate about security and innovation.
        </p>
        <p className="text-lg">
          Our mission is to empower users with advanced tools to protect their networks and data effectively.
        </p>
      </div>
    </div>
    
  );
};

export default AboutUs;
